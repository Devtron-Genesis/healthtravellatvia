Instead of placing the downloaded external libs (such as TCPDF, dompdf,
etc.) used by the print module here, you should place them in
sites/all/libraries.

This directory is still a valid location for them, however. The Libraries
API module library path is also valid.
