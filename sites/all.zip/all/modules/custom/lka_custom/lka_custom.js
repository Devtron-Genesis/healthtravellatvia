(function ($) {
  Drupal.lkaCustom = Drupal.lkaCustom || {};

  Drupal.lkaCustom.transitionBegin = function (options) {

    
  };
})(jQuery);
