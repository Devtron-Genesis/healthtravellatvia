<div<?php print $attributes; ?>>
  <?php print $content; ?>
</div>