<section<?php print $attributes; ?>>
  <?php print $content; ?>
</section>