<?php

/**
 * @file
 * This file is empty by default because the base theme chain (Alpha & Omega) provides
 * all the basic functionality. However, in case you wish to customize the output that Drupal
 * generates through Alpha & Omega this file is a good place to do so.
 *
 * Alpha comes with a neat solution for keeping this file as clean as possible while the code
 * for your subtheme grows. Please read the README.txt in the /preprocess and /process subfolders
 * for more information on this topic.
 */

/**
 * Implements hook_preprocess_html().
 */
function lka_alpha_preprocess_html(&$vars) {
  $theme = alpha_get_theme();
  $vars['rdf'] = new stdClass;

  if (module_exists('rdf')) {
    $vars['doctype'] = '<!DOCTYPE html PUBLIC "-//W3C//DTD HTML+RDFa 1.1//EN">' . "\n";
    $vars['rdf']->version = ' version="HTML+RDFa 1.1"';
    $vars['rdf']->namespaces = $vars['rdf_namespaces'];
    $vars['rdf']->profile = ' profile="' . $vars['grddl_profile'] . '"';
  }
  else {
    $vars['doctype'] = '<!DOCTYPE html>' . "\n";
    $vars['rdf']->version = '';
    $vars['rdf']->namespaces = '';
    $vars['rdf']->profile = '';
  }

  if (alpha_library_active('omega_mediaqueries')) {
    $layouts = array();

    if (isset($theme->grids[$theme->settings['grid']])) {
      foreach ($theme->grids[$theme->settings['grid']]['layouts'] as $layout) {
        if ($layout['enabled']) {
          $layouts[$layout['layout']] = $layout['media'];
        }
      }

      drupal_add_js(array('omega' => array(
        'layouts' => array(
          'primary' => $theme->grids[$theme->settings['grid']]['primary'],
          'order' => array_keys($layouts),
          'queries' => $layouts,
        ),
      )), 'setting');
    }
  }
  $options = array(
    'type' => 'file',
    'weight' => '-10'
  );

  drupal_add_library('system', 'ui');
  drupal_add_library('system', 'ui.draggable');
  drupal_add_library('system', 'jquery.cookie');
  drupal_add_js(drupal_get_path('theme', 'lka'). '/js/slimScroll.min.js', $options);
  drupal_add_js(drupal_get_path('theme', 'lka'). '/js/scripts.js', $options);
  drupal_add_js(drupal_get_path('theme', 'lka'). '/js/jquery.mousewheel.js', $options);
  // drupal_add_js(drupal_get_path('theme', 'lka'). '/js/jquery.selectbox-0.1.3.min.js', $options);

  if(arg(0) == 'taxonomy' and is_numeric(arg(2)))
  {
    $termParent = taxonomy_get_parents(arg(2));

    if( ! empty($termParent))
    {
      $parent = reset($termParent);
      
      if(isset($parent->vocabulary_machine_name) and $parent->vocabulary_machine_name == 'pakalpojumi')
      {
        $vars['attributes_array']['class'][] = 'taxonomy-term-parent-is-'.$parent->tid;
        $vars['attributes_array']['class'][] = 'taxonomy-vocabulary-pakalpojumi';
      }
    }
    else
    {
      $term = taxonomy_term_load(arg(2));

      if($term and $term->vocabulary_machine_name == 'pakalpojumi')
      {
        $vars['attributes_array']['class'][] = 'taxonomy-term-parent-is-'.$term->tid;
        $vars['attributes_array']['class'][] = 'taxonomy-vocabulary-pakalpojumi';
      }
    }
  }
}


/**
 * Implements hook_preprocess_page().
 */
function lka_alpha_preprocess_page(&$vars) {
  $theme = alpha_get_theme();
  $theme->page = &$vars;

  $vars['feed_icons'] = $theme->settings['toggle']['feed_icons'] ? $vars['feed_icons'] : NULL;
  $vars['tabs'] = $theme->settings['toggle']['tabs'] ? $vars['tabs'] : NULL;
  $vars['action_links'] = $theme->settings['toggle']['action_links'] ? $vars['action_links'] : NULL;
  $vars['show_messages'] = $theme->settings['toggle']['messages'] ? $vars['show_messages'] : FALSE;
  $vars['site_name_hidden'] = $theme->settings['hidden']['site_name'];
  $vars['site_slogan_hidden'] = $theme->settings['hidden']['site_slogan'];
  $vars['title_hidden'] = $theme->settings['hidden']['title'];
  $vars['attributes_array']['id'] = 'page';
  $vars['attributes_array']['class'][] = 'clearfix';

  $vars['classes_array'][] = 'test';

}
