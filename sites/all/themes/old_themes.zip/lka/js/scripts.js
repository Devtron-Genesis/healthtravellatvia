(function ($) {
    Drupal.behaviors.lka = {
        attach: function(context, settings) {
            $(window).load(function(){
                var activeElement = $('.views-slideshow-pager-field-item.active');
                var pcalss = activeElement.find('span').attr('class');

                if(pcalss){
                    $('.p'+pcalss).addClass('active theOne');
                }

                $('.views-slideshow-pager-field-item').click(function(){
                    activeElement = this;
                    $('.pilseta_punkts .active').removeClass('active');
                    var p_class = $(this).find('span').attr('class');
                    $('.p'+p_class).addClass('active');

                  $('.views-slideshow-pager-field-item').removeClass('active');
                  $(this).addClass('active');
                });

                $('.views-slideshow-pager-field-item:not(.active)').hover(function(){
                    $(this).addClass('active');
                },function(){
                    if(this != activeElement)
                        $(this).removeClass('active');
                });

                $('#block-views-pilsetas-block-1 .views-row, .views-slideshow-pager-field-item').hover(function(){
                        var active_elem = $(this).find('span').attr('class');
                        $('.p'+active_elem).addClass('active');
                    },
                    function() {
                        var active_elem = $(this).find('span').attr('class');
                        if(this != activeElement)
                            $('.p'+active_elem.split(' ')[0]).removeClass('active');
                    }
                );

                // Add active class to views-row
                $('.view-display-id-pakalpojumi .views-row').each(function(index) {
                    var active_class = $(this).find('.link').attr('class');
                    $(this).addClass(active_class);
                });

                $('.view-pilsetas .views-slideshow-pager-field-item').each(function(index) {
                    $(this).click(function() {
                      $('.views-slideshow-controls-text-pause:not(.views-slideshow-controls-text-status-pause)').trigger('click');
                    });
                });

                $('.box-inner').slimScroll({
                    height: '290px',
                    size: '10px',
                    railVisible: true,
                    alwaysVisible: false,
                    railColor: '',
                    color: '#cddddc',
                    opacity: '0.8',
                    disableFadeOut: true
                });

                // $('.form-item-pilseta select').selectbox();

            });

            $(document).ready(function() {
                if($.cookie('TEXT_SIZE')) {
                    $('body').addClass($.cookie('TEXT_SIZE'));
                }
                $('.resizer a').click(function() {
                    var textSize = $(this).attr('class');
                    $('body').removeClass('small medium large').addClass(textSize);
                    $.cookie('TEXT_SIZE',textSize, { path: '/', expires: 10000 });
                    return false;
                });
                
                if ($('#zone-content-wrapper .back-link').length){
                    var bg = $('#zone-content-wrapper .back-link ').css('background-image').replace('url("','').replace('")','').replace('url(','').replace(')','');
                    switch(bg) {
                        case 'http://www.healthtravellatvia.lv/sites/all/themes/lka/images/spa-full.jpg':
                            $('#block-block-5 a ').css('background', '#bed82f');
                        break;
                        case 'http://www.healthtravellatvia.lv/sites/all/themes/lka/images/med-full.jpg':
                            $('#block-block-5 a ').css('background', '#9dc9bc');
                        break;
                        case 'http://www.healthtravellatvia.lv/sites/all/themes/lka/images/skaistums-full.jpg':
                            $('#block-block-5 a ').css('background', '#9cc3d4');
                        break;
                        case 'http://www.healthtravellatvia.lv/sites/all/themes/lka/images/kirurgija-full.jpg':
                            $('#block-block-5 a ').css('background', '#df968d');
                        break;
                        case 'http://www.healthtravellatvia.lv/sites/all/themes/lka/images/zobarsti-full.jpg':
                            $('#block-block-5 a ').css('background', '#f9a964');
                        break;
                        case 'http://www.healthtravellatvia.lv/sites/all/themes/lka/images/piedavajumi-full.jpg':
                            $('#block-block-5 a ').css('background', '#ffc74a');
                        break;
                        case 'http://www.healthtravellatvia.lv/sites/all/themes/lka/images/atbalsts-full.jpg':
                            $('#block-block-5 a ').css('background', '#ffdb2b');
                        break;
                    }
                }
            });
        }
    };

})(jQuery);
