<?php

/**
 * @file
 * Display Suite 1 column template.
 */
?>
<?php
$active_tid = arg(2);
$parent_tids_array = taxonomy_get_parents($active_tid);
foreach ($parent_tids_array as $parent_tid => $value) {
  $parent_tids[] = $parent_tid;
}
?>

<<?php print $ds_content_wrapper; print $layout_attributes; ?> class="ds-1col <?php print $classes;?> clearfix">

  <?php if (isset($title_suffix['contextual_links'])): ?>
  <?php print render($title_suffix['contextual_links']); ?>
  <?php endif; ?>

  <?php if (isset($parent_tids)): ?>
    
  <?php endif; ?>

  <?php print $ds_content; ?>
</<?php print $ds_content_wrapper ?>>

<?php if (!empty($drupal_render_children)): ?>
  <?php print $drupal_render_children ?>
<?php endif; ?>
