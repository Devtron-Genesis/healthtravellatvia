<?php
/**
 * @file views-view-unformatted.tpl.php
 * Default simple view template to display a list of rows.
 *
 * @ingroup views_templates
 */
// dpm(get_defined_vars());
?>
<?php

if($view->current_display == 'pakalpojumi_saraksts')
{
  $halfRows = ceil(count($rows)/2);

  $rows1 = array_slice($rows, 0, $halfRows);

  $rows2 = ($halfRows >= 1) ? array_slice($rows, $halfRows) : false;
}
else
{
  $rows1 = $rows;
}

$active_tid = arg(2);
$parent_tids_array = taxonomy_get_parents($active_tid);
foreach ($parent_tids_array as $parent_tid => $value) {
  $parent_tids[] = $parent_tid;
}
?>
<?php if (!empty($title)): ?>
  <h3><?php print $title; ?></h3>
<?php endif; ?>
<?php if($view->current_display == 'pakalpojumi_saraksts'): ?>
  <div class="col1">
<?php endif; ?>
<?php foreach ($rows1 as $id => $row): ?>
  <?php if (isset($parent_tids) && in_array($view->result[$id]->tid, $parent_tids)) {
    $active_class = 'active';
  }
  else {
    $active_class = '';
  }
  ?>
  <div class="<?php print $classes_array[$id]; ?> <?php print $active_class; ?>">
    <?php print $row; ?>
  </div>
<?php endforeach; ?>
<?php if($view->current_display == 'pakalpojumi_saraksts'): ?>
</div>
<?php endif; ?>


<?php if($rows2): ?>
  <div class="col2">
<?php foreach ($rows2 as $id => $row): ?>
  <?php if (isset($parent_tids) && in_array($view->result[$id]->tid, $parent_tids)) {
    $active_class = 'active';
  }
  else {
    $active_class = '';
  }
  ?>
  <div class="<?php print $classes_array[$id]; ?> <?php print $active_class; ?>">
    <?php print $row; ?>
  </div>
<?php endforeach; ?>
</div>
<?php endif; ?>

