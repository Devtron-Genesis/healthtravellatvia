<div class="topheader">
<div class="container">
	<!-- <div class="pull-left hidden-xs">
    	<span><img src="<?php //print drupal_get_path('theme', 'health');
 ?>/img/email-icon.png"> info@healthtravellatvia. lv</span>
    	<span><img src="<?php //print drupal_get_path('theme', 'health');
 ?>/img/phone-icon.png">  +371 67147905</span>
    </div> -->
    <?php print render($page['top-contact']); ?>
    <div class="pull-right">
    	<div class="text-inc">
        <!-- <select>
        	<option>English</option>
        </select> -->
        <?php print render($page['language']); ?>
    	<!-- <a href="" class="large-a">A</a> |
    	<a href="" class="medium-a">A</a> |
    	<a href="" class="small-a">A</a> -->
    	<a href=""><img src="<?php base_path().print drupal_get_path('theme', 'health');
 ?>/img/print-icon.png"></a>
        </div>
    </div>
</div>
</div>
<!-- Top-section-->
<!-- Header -->
<div class="menu">
<nav class="navbar navbar-default">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="<?php echo base_path(); ?>"><img src="<?php echo $logo; ?>"></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <?php 
           print render($main_menu);
       ?>
      
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
</div>
<!-- Header -->
<!-- Menu-->
<div class="slider">
<div class="new-menu">

<nav class="navbar navbar-default">
  <div class="">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2" aria-expanded="false">
        <span class="meni-show">Main Menu</span>
      </button>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-2">
      <?php
        $primary_menu = menu_navigation_links('menu-primary-menu');
       print theme('links__menu_primary_menu', array('links' => $primary_menu, 'attributes' => array('class' => array('nav','navbar-nav')))); ?>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
</div>
<!--Menu-->
<!-- Slider-->
<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img src="<?php print drupal_get_path('theme', 'health');
 ?>/img/banner.png" alt="...">
      <div class="carousel-caption">
        WHO WE ARE
        TECHNOLOGIES
        DOCTORS
      </div>
    </div>
    <div class="item">
      <img class="front-banner-img" src="<?php print drupal_get_path('theme', 'health');
 ?>/img/banner.png" alt="...">
      <div class="carousel-caption">
        WHO WE ARE
        TECHNOLOGIES
        DOCTORS
      </div>
    </div>
    <div class="item">
      <img src="<?php print drupal_get_path('theme', 'health');
 ?>/img/banner.png" alt="...">
      <div class="carousel-caption">
        WHO WE ARE
        TECHNOLOGIES
        DOCTORS
      </div>
    </div>
  </div>

</div>
</div>
<!-- Slider-->
<!-- Slider-lower-->
<div class="low-slider">
	<div class="container">
    	<div class="row">
        	<div class="col-xs-12 col-sm-9 news-front">
              <?php 
                    $viewName = 'jaunumi';
                    print views_embed_view($viewName);
               ?>
            	<!-- <div class="loser-content">
                	<h2>PROGRAMMA “TIEVĒ VESELĪGI UN GUDRI”</h2>
                    <p>Saule aiz loga, kaut gan vēl ar “zobiņiem”, signalizē, ka pienācis laiks lielajai pavasara tīrīšanai – ķermenim un garam un ja to vēl var darīt kopā ar kolēģēm, draudzenēm vai mammu, ko ikdienas steigā sanāk satikt pavisam reti! Mūsu devīze: domā – pareizi, ēd – veselīgi; vingro – katru dienu; mīli... <a href="">Lasīt vairāk</a></p><br>
                	<h2>LKA piedalās lielākajā Ziemeļvalstu tūrisma izstādē „MATKA 2017”</h2>
                    <p>No 19. līdz 22. janvārim biedrība “Latvijas kūrortpilsētu asociācija” ar Latvijas veselības tūrisma klasteri un tā biedriem, Profesionālās mikropigmentācijas centru, Sky dream clinic, Baltic Care, J.Ģīļa klīniku, Veselības centru 4 piedalās starptautiskajā tūrisma izstādē Somijā „MATKA 2017”, kas ir vislielākā Ziemeļvalstu tūrisma izstāde ...  <a href="">Lasīt vairāk</a></p>
                </div> -->
            </div>
            <div class="col-xs-12 col-sm-3">
              <?php print render($page['jaunumi-slider']); ?>
         
            </div>
        </div>
    </div>
</div>
<!-- Slider-lower-->
<!-- content-->
<div class="PAKALPOJUMI">
	<div class="container">
    	<!-- <h2 class="home-head">PAKALPOJUMI</h2>  -->
      <?php print render($page['pakalpojumi']); ?>
    </div>
</div>
<!-- content-->
<!-- Saulkrasti-->
<?php 
    //$viewName = 'pilsetas';
    print render($page['pilsetas']);
    //echo views_embed_view('pilsetas', 'block');
?>
<!-- Saulkrasti-->
<!-- form-->
<div class="home-form">
	<div class="container">
    	<div class="row">
        	<div class="col-sm-4">
            	<h2><?php echo t('Event calendar'); ?></h2>
              <?php print render($page['calendar']); ?>
          </div>
        	<div class="col-sm-8">
            	<h2><?php echo t('Contact us'); ?></h2>
                <div class="row">
                  <?php print render($page['contact']); ?>
                	<!-- <div class="col-sm-6">                    	
                        
                        <div class="form-group">
                          <label class="col-md-12 control-label">Full Name</label>  
                          <div class="col-md-12">
                          <input class="form-control" type="text">                        
                          </div>
                        </div>            	
                        
                        <div class="form-group">
                          <label class="col-md-12 control-label">Email</label>  
                          <div class="col-md-12">
                          <input class="form-control" type="email">                        
                          </div>
                        </div>            	
                        
                        <div class="form-group">
                          <label class="col-md-12 control-label">Phone</label>  
                          <div class="col-md-12">
                          <input class="form-control" type="text">                        
                          </div>
                        </div>
                    </div>
                    
                    
                    <div class="col-sm-6">                    	
                        
                        <div class="form-group">
                          <label class="col-md-12 control-label">Your Message</label>  
                          <div class="col-md-12">
                          <textarea class="form-control" rows="5"></textarea>                        
                          </div>
                        </div>            	
                        
                        <div class="form-group text-right">
                          <div class="col-md-12">
                         		<a href="" class="btn btn-success">SUBMIT</a>                 
                          </div>
                        </div>
                    </div> -->
                     
                </div>
            	
            </div>
        </div>
    </div>
</div>
<!-- form-->
<!-- Footer-->
<div class="footer">
	<div class="container">
    	<div class="row">
        	<div class="col-sm-6">
          <?php print render($page['footer-left']); ?>
            	
            </div>

        	<div class="col-sm-6">
            	<h3><?php echo t('Follow us on social networks'); ?></h3>
              <?php print render($page['footer-right']); ?>
                <!-- <div class="col-sm-8 col-sm-offset-2">
                <div class="input-group">
                    <input value="" name="EMAIL" class="form-control" type="email">
                    <span class="input-group-btn">
                    <input class="button btn btn-success" value="SUBMIT" type="submit">
                    </span>
                </div>
                </div> -->
            </div>
        </div>
    </div>
</div>
<!-- Footer-->
<!-- coptright-->
<div class="copyright">
	<div class="container">
    <?php print render($page['footer']); ?>
  </div>
</div>
<!-- coptright