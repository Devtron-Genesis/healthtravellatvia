<div class="topheader">
<div class="container">
	<!-- <div class="pull-left hidden-xs">
    	<span><img src="<?php //print drupal_get_path('theme', 'health');
 ?>/img/email-icon.png"> info@healthtravellatvia. lv</span>
    	<span><img src="<?php //print drupal_get_path('theme', 'health');
 ?>/img/phone-icon.png">  +371 67147905</span>
    </div> -->
    <?php print render($page['top-contact']); ?>
    <div class="pull-right">
    	<div class="text-inc">
        <!-- <select>
        	<option>English</option>
        </select> -->
        <?php print render($page['language']); ?>
    	<!-- <a href="" class="large-a">A</a> |
    	<a href="" class="medium-a">A</a> |
    	<a href="" class="small-a">A</a> -->
    	<a href=""><img src="<?php print base_path().drupal_get_path('theme', 'health');
 ?>/img/print-icon.png"></a>
        </div>
    </div>
</div>
</div>
<!-- Top-section-->
<!-- Header -->
<div class="menu">
<nav class="navbar navbar-default">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="<?php echo base_path(); ?>"><img src="<?php echo $logo; ?>"></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <?php 
           print render($main_menu);
       ?>
      
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
</div>
<!-- Header -->
<!-- Menu-->
<div class="slider">
<div class="new-menu menu-tpl">

<nav class="navbar navbar-default">
  <div class="">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2" aria-expanded="false">
        <span class="meni-show">Main Menu</span>
      </button>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-2">
      <?php
        $primary_menu = menu_navigation_links('menu-primary-menu');
       print theme('links__menu_primary_menu', array('links' => $primary_menu, 'attributes' => array('class' => array('nav','navbar-nav')))); ?>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
</div>
<!--Menu-->

<!--Content-->
<div class="about">
<div class="container">
<div class="fullwidth">
  <div class="col-sm-3">
      <div class="left-menu">
          <!-- <ul>
              <li><a href="">ABOUT ASSOCIATION</a></li>
              <li><a href="">GOALS</a></li>
              <li><a href="">PROJECT</a></li>
              <li><a href="">MEMBERS</a></li>
              <li><a href="">CONTACT</a></li> 
            </ul> -->
            <?php print render($page['left-sidebar']); ?>
      </div>
    </div>
  <div class="col-sm-6">
      <div class="about-content">
          <?php if ($title): ?>
            <h2 class="title" id="page-title">
              <?php print $title; ?>
            </h2>
          <?php endif; ?>

          <?php 
          print $tab;
          print render($page['content']); ?>
        </div>
    </div>
  <div class="col-sm-3">
      <div class="form-main">
            <?php print render($page['contact']); ?>          
        </div>
             
        <div class="right-slider">
          <?php print render($page['jaunumi-slider']); ?>
        </div>
    </div>
</div>
</div>
</div>
<!-- Content-->

<!--icons above footer-->
<div class="PAKALPOJUMI">
	<div class="container">
    	<!-- <h2 class="home-head">PAKALPOJUMI</h2>  -->
      <?php print render($page['pakalpojumi']); ?>
    </div>
</div>
<!--icons above footer-->

<!-- Footer-->
<div class="footer">
	<div class="container">
    	<div class="row">
        	<div class="col-sm-6">
          <?php print render($page['footer-left']); ?>
            	
            </div>

        	<div class="col-sm-6">
            	<h3><?php echo t('Follow us on social networks'); ?></h3>
              <?php print render($page['footer-right']); ?>
                <!-- <div class="col-sm-8 col-sm-offset-2">
                <div class="input-group">
                    <input value="" name="EMAIL" class="form-control" type="email">
                    <span class="input-group-btn">
                    <input class="button btn btn-success" value="SUBMIT" type="submit">
                    </span>
                </div>
                </div> -->
            </div>
        </div>
    </div>
</div>
<!-- Footer-->
<!-- coptright-->
<div class="copyright">
	<div class="container">
    <?php print render($page['footer']); ?>
  </div>
</div>
<!-- coptright