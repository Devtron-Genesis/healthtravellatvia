<?php
function health_preprocess_html(&$vars) {

	$X_UA_Compatible = array(
	  '#tag' => 'meta', 
	  '#attributes' => array(
	    'name' => 'X-UA-Compatible', 
	    'content' => 'IE=edge',
	  ),
	);

	$viewport = array(
	  '#tag' => 'meta', 
	  '#attributes' => array(
	    'name' => 'viewport', 
	    'content' => 'width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=0',
	  ),
	);

	$apple_mobile_web_app_capable = array(
	  '#tag' => 'meta', 
	  '#attributes' => array(
	    'name' => 'apple-mobile-web-app-capable', 
	    'content' => 'yes',
	  ),
	);
 
	drupal_add_html_head($X_UA_Compatible, 'X-UA-Compatible');
	drupal_add_html_head($viewport, 'viewport');
	drupal_add_html_head($apple_mobile_web_app_capable, 'apple-mobile-web-app-capable');

}

function health_form_alter(&$form, &$form_state, $form_id){

	if($form_id == 'search_block_form'){
		
		$form['search_block_form']['#prefix'] = '<div class="search">';
		$form['search_block_form']['#suffix'] = '<button type="submit" class="btn btn-success btn-sm"><i class="fa fa-search"></i></button>';
    	$form['search_block_form']['#attributes']['placeholder'] = t('Search');
    	$form['search_block_form']['#attributes']['class'] = array('form-control input-sm');
    	$form['actions']['submit']['#access'] = false;
    	//$form['actions']['submit']['#attributes']['class'] = array('btn btn-success btn-sm');
    	$form['actions']['submit']['#value'] = '';
	}

	if($form_id == 'simplenews_block_form_749'){
		
		$form['mail']['#title'] = '';
		$form['mail']['#attributes'] = array('class'=>array('form-control'));
		$form['mail']['#prefix'] = '<div class="col-sm-8 col-sm-offset-2"><div class="input-group">';

		$form['submit']['#value'] = t('Submit');
		$form['submit']['#attributes'] = array('class'=>array('button btn btn-success'));
		$form['submit']['#prefix'] = '<span class="input-group-btn">';
		$form['submit']['#suffix'] = '</span></div></div>';

	}
	//echo $is_front;exit();
	if(drupal_is_front_page()){
		
		if($form_id == 'webform_client_form_164'){

			//echo "<pre>"; print_r($form); exit();
			$form['#node']->title = '';
			$form['submitted']['vards_uzvards']['#title'] = '';
			$form['submitted']['vards_uzvards']['#prefix'] = '<div class="col-sm-6"><div class="form-group"><label class="col-md-12 control-label">'.t('Full Name').'</label><div class="col-md-12">';
			$form['submitted']['vards_uzvards']['#suffix'] = '</div></div>';
			$form['submitted']['vards_uzvards']['#attributes'] = array('class'=>array('form-control'));

			$form['submitted']['kontakttalrunis']['#title'] = '';
			$form['submitted']['kontakttalrunis']['#attributes'] = array('class'=>array('form-control'));
			$form['submitted']['kontakttalrunis']['#prefix'] = '<div class="form-group"><label class="col-md-12 control-label">'.t('Phone').'</label><div class="col-md-12">';
			$form['submitted']['kontakttalrunis']['#suffix'] = '</div></div>';

			$form['submitted']['jusu_e_pasts']['#title'] = '';
			$form['submitted']['jusu_e_pasts']['#prefix'] = '<div class="form-group"><label class="col-md-12 control-label">'.t('Email').'</label><div class="col-md-12">';
			$form['submitted']['jusu_e_pasts']['#suffix'] = '</div></div></div>';
			$form['submitted']['jusu_e_pasts']['#attributes'] = array('class'=>array('form-control'));

			$form['submitted']['komentars_vai_jautajums']['#title'] = '';
			$form['submitted']['komentars_vai_jautajums']['#attributes'] = array('class'=>array('form-control'));
			$form['submitted']['komentars_vai_jautajums']['#prefix'] = '<div class="col-sm-6"><div class="form-group"><label class="col-md-12 control-label">'.t('Your Message').'</label><div class="col-md-12">';
			$form['submitted']['komentars_vai_jautajums']['#suffix'] = '</div></div>';

			$form['actions']['submit']['#value'] = t('SUBMIT');
			$form['actions']['submit']['#attributes'] = array('class'=>array('btn btn-success'));
			$form['actions']['submit']['#prefix'] = '<div class="form-group text-right"><div class="col-md-12">';
			$form['actions']['submit']['#suffix'] = '</div></div></div>';

			$form['submitted']['organizacija']['#access'] = false;

		}

	}
	elseif(!drupal_is_front_page()){
	  

		if($form_id == 'webform_client_form_164' || $form_id == 'webform_client_form_139' || $form_id == 'webform_client_form_165'){

			$form['#node']->title = '';
			$form['#attributes'] = array('class'=>array('form-horizontal'));
			//echo "<pre>"; print_r($form['submitted']); exit();
			$form['submitted']['vards_uzvards']['#title'] = '';
			$form['submitted']['vards_uzvards']['#prefix'] = '<h3>'.t('Have a question?').'</h3>
            <h5>'.t('Get in touch!').'</h5><div class="form-group"><label class="col-md-12 control-label">'.t('Full Name').'</label><div class="col-md-12">';
			$form['submitted']['vards_uzvards']['#suffix'] = '</div></div>';
			$form['submitted']['vards_uzvards']['#attributes'] = array('class'=>array('form-control'));

			$form['submitted']['jusu_e_pasts']['#title'] = '';
			$form['submitted']['jusu_e_pasts']['#prefix'] = '<div class="form-group"><label class="col-md-12 control-label">'.t('Email').'</label><div class="col-md-12">';
			$form['submitted']['jusu_e_pasts']['#suffix'] = '</div></div>';
			$form['submitted']['jusu_e_pasts']['#attributes'] = array('class'=>array('form-control'));

			$form['submitted']['kontakttalrunis']['#title'] = '';
			$form['submitted']['kontakttalrunis']['#prefix'] = '<div class="form-group"><label class="col-md-12 control-label">'.t('Phone').'</label><div class="col-md-12">';
			$form['submitted']['kontakttalrunis']['#suffix'] = '</div></div>';
			$form['submitted']['kontakttalrunis']['#attributes'] = array('class'=>array('form-control'));

			$form['submitted']['organizacija']['#title'] = '';
			$form['submitted']['organizacija']['#prefix'] = '<div class="form-group"><label class="col-md-12 control-label">'.t('Organization').'</label><div class="col-md-12">';
			$form['submitted']['organizacija']['#suffix'] = '</div></div>';
			$form['submitted']['organizacija']['#attributes'] = array('class'=>array('form-control'));

			$form['submitted']['komentars_vai_jautajums']['#title'] = '';
			$form['submitted']['komentars_vai_jautajums']['#attributes'] = array('class'=>array('form-control'));
			$form['submitted']['komentars_vai_jautajums']['#prefix'] = '<div class="form-group"><label class="col-md-12 control-label">'.t('Message').'</label><div class="col-md-12">';
			$form['submitted']['komentars_vai_jautajums']['#suffix'] = '</div></div>';

			$form['actions']['submit']['#value'] = t('SEND MESSAGE');
			$form['actions']['submit']['#attributes'] = array('class'=>array('btn btn-success'));
			$form['actions']['submit']['#prefix'] = '<div class="form-group"><div class="col-md-12">';
			$form['actions']['submit']['#suffix'] = '</div></div><p>'.t('all fields are required').'</p>';

			//$form['submitted']['kontakttalrunis']['#access'] = false;
			//$form['submitted']['organizacija']['#access'] = false;
		}
	}
	

}

function health_preprocess_page(&$vars) {
	if(isset($vars['page']['content']['system_main']['no_content'])) {
    	unset($vars['page']['content']['system_main']['no_content']);
  	}
  	$main_menu_tree = menu_tree('main-menu');
  	$vars['main_menu'] = theme('main_header_links',array('links' => $main_menu_tree));
   
}

function health_theme() {
	return array(
        'main_header_links' => array(
            'links' => NULL,
        ),
	 );
}

function health_main_header_links($links){
  $menu_links = $links['links'];
  $attributes = array();
  $heading = '';
  global $language_url;
  $output = '';
  $class2 = '';

  $icon = array('icon-desktop', 'icon-heart', 'icon-home', 'icon-briefcase', 'icon-star', 'icon-cog', 'icon-plus-sign-alt', 'icon-smile', 'icon-flag-checkered', 'icon-flag-checkered');
  //echo "<pre>"; print_r($links); exit;
  if (count($menu_links) > 0) {
    $output = '';

    // Treat the heading first if it is present to prepend it to the
    // list of links.
    
    if (!empty($heading)) {
      if (is_string($heading)) {
      // Prepare the array that will be used when the passed heading
      // is a string.
        $heading = array(
          'text' => $heading,
          // Set the default level of the heading.
          'level' => 'h2',
        );
      }
 
      $output .= '<' . $heading['level'];
  
      if (!empty($heading['class'])) {
        //$output .= drupal_attributes(array('class' => $heading['class']));
      }
  
      $output .= '>' . check_plain($heading['text']) . '</' . $heading['level'] . '>';
    }

    $output .= '<ul class="nav navbar-nav navbar-right search-menu">';

    $num_links = 0;
    foreach ($menu_links as $key => $link) {
      if(is_numeric($key)){
        $num_links++;
      }
    }

    $i = 1;

    foreach ($menu_links as $key => $link) {
      if(!is_numeric($key)){
          continue;
      }
      $class = array($key);
      $class[] = 'top_level';

    // Add first, last and active classes to the list of links to help out themers.
      if ($i == 1) {
        $class[] = 'first';
      }
      if ($i == $num_links) {
        $class[] = 'last';
      }
      
      if (isset($link['#href']) && ($link['#href'] == $_GET['q'] || (($link['#href'] == '<front>' || empty($link['#href'])) && drupal_is_front_page()))
             && (empty($link['language']) || $link['language']->language == $language_url->language)) {
        $class[] = 'active';
      }
      
      $output .= '<li' . drupal_attributes(array('class' => $class)) . '>';

      if (isset($link['#href'])) {
        if (strpos($link['#href'], 'nolink')) {
          $output .= '<a class="nolink">' . $link['#title'] . '</a>';
        } else {
          $menutext = "<i class='".$icon[$i-1]." left_icon_list'></i> ".$link['#title']." <i class='icon-chevron-right pull-right right_arrow_list'></i>";
          $output .= l($menutext, drupal_get_path_alias($link["#href"]), array('html' => TRUE));
        }
        
        if($link['#below']){
          $class1 = '';
          if($i == $num_links-1){
            $class1 = 'news';
          }else if($i == $num_links){
            $class1 = 'about';
          }
          $output .= load_second_level_menu($link['#below'],$class1);  
        }        
      } elseif (!empty($link['#title'])) {
      
      // Some links are actually not links, but we wrap these in <span> for adding title and class attributes.
      if (empty($link['html'])) {
        $link['#title'] = check_plain($link['#title']);
      }
      
      $span_attributes = '';
      if (isset($link['attributes'])) {
        //$span_attributes = drupal_attributes($link['attributes']);
      }
    }

      $i++;
      $output .= "</li>\n";
    }
     $search_box1 = drupal_get_form('search_block_form');
     $search_box = drupal_render($search_box1);

     //echo "<pre>"; print_r(drupal_get_form('search_custom_module_form')); exit;
    $output .= '<li class="search-box-menu">'.$search_box.'</li>';

    $output .= '</ul>';
  }

  return $output;

}

function load_second_level_menu($sub_link,$extra_class = '') {
    $output = '';

    $num_links = 0;
    foreach ($sub_link as $key => $link) {
      if(is_numeric($key)){
        $num_links++;
      }
    }

    $class[] = "submenu";
    if(!empty($extra_class)){
      $class[] = $extra_class;
    }


    $output .= '<ul '. drupal_attributes(array('class' => $class)) .'>';
    $k = 1;
    foreach ($sub_link as $key => $link) {
        if(!is_numeric($key)){
          continue;
        }
        if ($k == $num_links) {
            $class[] = 'last';
        }
        //echo "<pre>"; print_r($link); exit;
        $output .= '<li>';                        
            $output .= l($link['#title'], $link['#href']);
            if($link['#below']){
              $output .= load_second_level_menu($link['#below']);
            }
        $output .='</li>';
             
        $k++;
    }

    $output .= '</ul>';

    return $output;
}